#
# Generated Code - Do Not Edit
#


import copy as _copy
import json as _json

from cyclecloud import model as _model


class _RequestContext(object):
    def __init__(self):
        self.url = None
        self.host = None
        self.path = None


def create_nodes(session, cluster, nodes):
    """
    This operation adds new nodes from a nodearray to a cluster. It accepts multiple node definitions in a single call. It returns the URL to the operation that can be used to track the status of the operation.

    Parameters:
    cluster: string, The cluster to add nodes to, Required
    nodes: object, Sets of nodes to be created, Required

    Returns: (status, data)
    (202, NodeCreationResult)
    (409, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not nodes:
        raise ValueError('nodes is required.')

    _request_context = _RequestContext()

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/nodes/create".format(**_path_parameters)

    _query = {}

    _headers = {}

    _body = None
    if type(nodes) is dict:
        _body = _json.dumps(nodes)
    else:
        _body = nodes.json_encode()

    _responses = []
    _responses.append((202, 'object', _model.NodeCreationResult.from_dict))

    _status, _response = session.request(_request_context, 'POST', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def deallocate_nodes(session, cluster, action):
    """
    This operation deallocates nodes in a cluster. The nodes can be identified in several ways,  including node name, node id, or by filter.

    Parameters:
    cluster: string, The cluster to deallocate nodes in, Required
    action: object, Description of which nodes to deallocate, Required

    Returns: (status, data)
    (202, NodeManagementResult)
    (409, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not action:
        raise ValueError('action is required.')

    _request_context = _RequestContext()

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/nodes/deallocate".format(**_path_parameters)

    _query = {}

    _headers = {}

    _body = None
    if type(action) is dict:
        _body = _json.dumps(action)
    else:
        _body = action.json_encode()

    _responses = []
    _responses.append((202, 'object', _model.NodeManagementResult.from_dict))

    _status, _response = session.request(_request_context, 'POST', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def terminate_nodes(session, cluster, action):
    """
    This operation terminates nodes in a cluster. The nodes can be identified in several ways,  including node name, node id, or by filter.

    Parameters:
    cluster: string, The cluster to terminate nodes in, Required
    action: object, Description of which nodes to terminate, Required

    Returns: (status, data)
    (202, NodeManagementResult)
    (409, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not action:
        raise ValueError('action is required.')

    _request_context = _RequestContext()

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/nodes/terminate".format(**_path_parameters)

    _query = {}

    _headers = {}

    _body = None
    if type(action) is dict:
        _body = _json.dumps(action)
    else:
        _body = action.json_encode()

    _responses = []
    _responses.append((202, 'object', _model.NodeManagementResult.from_dict))

    _status, _response = session.request(_request_context, 'POST', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def remove_nodes(session, cluster, action):
    """
    This operation removes nodes in a cluster. The nodes can be identified in several ways,  including node name, node id, or by filter. Note that by default nodes are removed when terminated (unless the node has Fixed set to true), in which case this call is no different than terminate.

    Parameters:
    cluster: string, The cluster to remove nodes in, Required
    action: object, Description of which nodes to remove, Required

    Returns: (status, data)
    (202, NodeManagementResult)
    (409, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not action:
        raise ValueError('action is required.')

    _request_context = _RequestContext()

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/nodes/remove".format(**_path_parameters)

    _query = {}

    _headers = {}

    _body = None
    if type(action) is dict:
        _body = _json.dumps(action)
    else:
        _body = action.json_encode()

    _responses = []
    _responses.append((202, 'object', _model.NodeManagementResult.from_dict))

    _status, _response = session.request(_request_context, 'POST', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def start_nodes(session, cluster, action):
    """
    This operation starts nodes in a cluster. The nodes can be identified in several ways,  including node name, node id, or by filter.

    Parameters:
    cluster: string, The cluster to start nodes in, Required
    action: object, Description of which nodes to start, Required

    Returns: (status, data)
    (202, NodeManagementResult)
    (409, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not action:
        raise ValueError('action is required.')

    _request_context = _RequestContext()

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/nodes/start".format(**_path_parameters)

    _query = {}

    _headers = {}

    _body = None
    if type(action) is dict:
        _body = _json.dumps(action)
    else:
        _body = action.json_encode()

    _responses = []
    _responses.append((202, 'object', _model.NodeManagementResult.from_dict))

    _status, _response = session.request(_request_context, 'POST', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def get_nodes(session, cluster, operation=None, request_id=None):
    """
    No description available
    Parameters:
    cluster: string, The cluster to query, Required
    operation: string, If given, returns only the nodes for this operation id, and includes the operation attribute on the body 
, Optional
    request_id: string, If given, returns only the nodes for the operation identified by this request id,
 and includes the operation attribute on the body 
, Optional

    Returns: (status, data)
    (200, NodeList)
    (404, async_url)
    (400, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')

    _request_context = _RequestContext()

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/nodes".format(**_path_parameters)

    _query = {}
    if operation:
        _query['operation'] = operation
    if request_id:
        _query['request_id'] = request_id

    _headers = {}

    _body = None

    _responses = []
    _responses.append((200, 'object', _model.NodeList.from_dict))

    _status, _response = session.request(_request_context, 'GET', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def get_cluster_status(session, cluster, nodes=None):
    """
    This operation contains information for the nodes and nodearrays in a given cluster. For each nodearray, it returns the status of each "bucket" of allocation that can be used, such as how many  nodes are in the bucket, how many more can be added, etc. Each bucket is a set of possible VMs of a given hardware profile, that can be created in a given location, under a given  customer account, etc. The valid buckets for a nodearray are determined by the user's cluster definition, but the limits are determined in part by the cloud provider.

    Parameters:
    cluster: string, The cluster to query, Required
    nodes: boolean, If true, nodes and node references are returned in the response, Optional

    Returns: (status, data)
    (200, ClusterStatus)
    """
    if not cluster:
        raise ValueError('cluster is required.')

    _request_context = _RequestContext()

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/status".format(**_path_parameters)

    _query = {}
    if nodes:
        _query['nodes'] = str(nodes).lower()

    _headers = {}

    _body = None

    _responses = []
    _responses.append((200, 'object', _model.ClusterStatus.from_dict))

    _status, _response = session.request(_request_context, 'GET', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def scale(session, cluster, nodearray, total_core_count=None, total_node_count=None):
    """
    This operation adds nodes as needed to a nodearray to hit a total count. The request is processed one time, and does not re-add nodes later to maintain the given number. This scales by either total cores or total nodes, but not both. It returns the URL to the operation that can be used to track the status of the operation.

    Parameters:
    cluster: string, The cluster to add nodes to, Required
    nodearray: string, The nodearray to add nodes to, Required
    total_core_count: integer, The total number of cores to have in this nodearray, including nodes already created
, Optional
    total_node_count: integer, The total number of machines to have in this nodearray, including nodes already created
, Optional

    Returns: (status, data)
    (202, NodeCreationResult)
    (409, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not nodearray:
        raise ValueError('nodearray is required.')

    _request_context = _RequestContext()

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _path_parameters["nodearray"] = nodearray
    _request_context.path = "/clusters/{cluster}/scale/{nodearray}".format(**_path_parameters)

    _query = {}
    if total_core_count:
        _query['totalCoreCount'] = total_core_count
    if total_node_count:
        _query['totalNodeCount'] = total_node_count

    _headers = {}

    _body = None

    _responses = []
    _responses.append((202, 'object', _model.NodeCreationResult.from_dict))

    _status, _response = session.request(_request_context, 'POST', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def shutdown_nodes(session, cluster, action):
    """
    This operation terminates or deallocates nodes in a cluster, depending on whether the ShutdownPolicy attribute on each node is Terminate (the default) or Deallocate, respectively. 

    Parameters:
    cluster: string, The cluster to shutdown nodes in, Required
    action: object, Description of which nodes to shutdown, Required

    Returns: (status, data)
    (202, NodeManagementResult)
    (409, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not action:
        raise ValueError('action is required.')

    _request_context = _RequestContext()

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/nodes/shutdown".format(**_path_parameters)

    _query = {}

    _headers = {}

    _body = None
    if type(action) is dict:
        _body = _json.dumps(action)
    else:
        _body = action.json_encode()

    _responses = []
    _responses.append((202, 'object', _model.NodeManagementResult.from_dict))

    _status, _response = session.request(_request_context, 'POST', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response



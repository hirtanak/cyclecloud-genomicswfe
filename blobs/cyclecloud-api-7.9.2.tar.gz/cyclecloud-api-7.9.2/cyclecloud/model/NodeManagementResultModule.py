#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from nojythonsupport.model import NodeManagementResult as _NodeManagementResult


    def json_decode(json_string):
        return _NodeManagementResult.json_decode(json_string)


    def from_dict(dict_obj):
        return _NodeManagementResult.from_dict(dict_obj)


    def NodeManagementResult(**kwargs):
        obj = _NodeManagementResult()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    NodeManagementResult.json_decode = _NodeManagementResult.json_decode
    NodeManagementResult.from_dict = _NodeManagementResult.from_dict


else:
    from .NodeManagementResultNodeModule import NodeManagementResultNode


    def json_decode(json_string):
        return NodeManagementResult.json_decode(json_string)


    def from_dict(dict_obj):
        return NodeManagementResult.from_dict(dict_obj)


    class NodeManagementResult(object):
        """
        
        nodes: [NodeManagementResultNode], An array of information about each node that matched the filter in the management request. Each node's status indicates if it was affected by the request.
, Required
        operation_id: string, The id of this operation, Required
        """

        def __init__(self, **kwargs):
            self.nodes = kwargs.get('nodes')
            self.operation_id = kwargs.get('operation_id')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.nodes is None:
                raise ValueError('Property NodeManagementResult.nodes is required.')
            if self.operation_id is None:
                raise ValueError('Property NodeManagementResult.operation_id is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.nodes is not None:
                dict_obj["nodes"] = [v.to_dict() for v in self.nodes]

            if self.operation_id is not None:
                dict_obj["operationId"] = self.operation_id

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = NodeManagementResult()

            value = dict_obj.get('nodes')
            if value is not None:
                obj.nodes = []
                for item in value:
                    obj.nodes.append(NodeManagementResultNode.from_dict(item))

            value = dict_obj.get('operationid')
            if value is not None:
                obj.operation_id = value

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return NodeManagementResult.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def nodes(self):
            """
            nodes: [NodeManagementResultNode], An array of information about each node that matched the filter in the management request. Each node's status indicates if it was affected by the request.
, Required
            """
            return self._nodes

        @nodes.setter
        def nodes(self, value):
            """
            nodes: [NodeManagementResultNode], An array of information about each node that matched the filter in the management request. Each node's status indicates if it was affected by the request.
, Required
            """
            if value:
                if type(value) is not list:
                    raise TypeError('Must supply a list for NodeManagementResult.nodes.')
            self._nodes = value

        @property
        def operation_id(self):
            """
            operation_id: string, The id of this operation, Required
            """
            return self._operation_id

        @operation_id.setter
        def operation_id(self, value):
            """
            operation_id: string, The id of this operation, Required
            """
            self._operation_id = value


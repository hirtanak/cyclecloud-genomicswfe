#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from nojythonsupport.model import NodearrayBucketStatusVirtualMachine as _NodearrayBucketStatusVirtualMachine


    def json_decode(json_string):
        return _NodearrayBucketStatusVirtualMachine.json_decode(json_string)


    def from_dict(dict_obj):
        return _NodearrayBucketStatusVirtualMachine.from_dict(dict_obj)


    def NodearrayBucketStatusVirtualMachine(**kwargs):
        obj = _NodearrayBucketStatusVirtualMachine()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    NodearrayBucketStatusVirtualMachine.json_decode = _NodearrayBucketStatusVirtualMachine.json_decode
    NodearrayBucketStatusVirtualMachine.from_dict = _NodearrayBucketStatusVirtualMachine.from_dict


else:


    def json_decode(json_string):
        return NodearrayBucketStatusVirtualMachine.json_decode(json_string)


    def from_dict(dict_obj):
        return NodearrayBucketStatusVirtualMachine.from_dict(dict_obj)


    class NodearrayBucketStatusVirtualMachine(object):
        """
        The properties of the virtual machines launched from this bucket
        vcpu_count: integer, The number of virtual CPUs this machine type has, Required
        infiniband: boolean, If this virtual machine supports InfiniBand connectivity, Required
        memory: float, The RAM in this virtual machine, in GB, Required
        """

        def __init__(self, **kwargs):
            self.vcpu_count = kwargs.get('vcpu_count')
            self.infiniband = kwargs.get('infiniband')
            self.memory = kwargs.get('memory')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.vcpu_count is None:
                raise ValueError('Property NodearrayBucketStatusVirtualMachine.vcpu_count is required.')
            if self.infiniband is None:
                raise ValueError('Property NodearrayBucketStatusVirtualMachine.infiniband is required.')
            if self.memory is None:
                raise ValueError('Property NodearrayBucketStatusVirtualMachine.memory is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.vcpu_count is not None:
                dict_obj["vcpuCount"] = self.vcpu_count

            if self.infiniband is not None:
                dict_obj["infiniband"] = self.infiniband

            if self.memory is not None:
                dict_obj["memory"] = self.memory

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = NodearrayBucketStatusVirtualMachine()

            value = dict_obj.get('vcpucount')
            if value is not None:
                obj.vcpu_count = value

            value = dict_obj.get('infiniband')
            if value is not None:
                obj.infiniband = value

            value = dict_obj.get('memory')
            if value is not None:
                obj.memory = value

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return NodearrayBucketStatusVirtualMachine.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def vcpu_count(self):
            """
            vcpu_count: integer, The number of virtual CPUs this machine type has, Required
            """
            return self._vcpu_count

        @vcpu_count.setter
        def vcpu_count(self, value):
            """
            vcpu_count: integer, The number of virtual CPUs this machine type has, Required
            """
            self._vcpu_count = value

        @property
        def infiniband(self):
            """
            infiniband: boolean, If this virtual machine supports InfiniBand connectivity, Required
            """
            return self._infiniband

        @infiniband.setter
        def infiniband(self, value):
            """
            infiniband: boolean, If this virtual machine supports InfiniBand connectivity, Required
            """
            self._infiniband = value

        @property
        def memory(self):
            """
            memory: float, The RAM in this virtual machine, in GB, Required
            """
            return self._memory

        @memory.setter
        def memory(self, value):
            """
            memory: float, The RAM in this virtual machine, in GB, Required
            """
            self._memory = value


#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from nojythonsupport.model import NodeManagementResultNode as _NodeManagementResultNode


    def json_decode(json_string):
        return _NodeManagementResultNode.json_decode(json_string)


    def from_dict(dict_obj):
        return _NodeManagementResultNode.from_dict(dict_obj)


    def NodeManagementResultNode(**kwargs):
        obj = _NodeManagementResultNode()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    NodeManagementResultNode.json_decode = _NodeManagementResultNode.json_decode
    NodeManagementResultNode.from_dict = _NodeManagementResultNode.from_dict


else:


    def json_decode(json_string):
        return NodeManagementResultNode.json_decode(json_string)


    def from_dict(dict_obj):
        return NodeManagementResultNode.from_dict(dict_obj)


    class NodeManagementResultNode(object):
        """
        
        status: string, One of OK or Error, Optional
        error: string, If the status is Error, this contains the error message, Optional
        id: string, The id of the node, Required
        name: string, The name of the node, Required
        """

        def __init__(self, **kwargs):
            self.status = kwargs.get('status')
            self.error = kwargs.get('error')
            self.id = kwargs.get('id')
            self.name = kwargs.get('name')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.id is None:
                raise ValueError('Property NodeManagementResultNode.id is required.')
            if self.name is None:
                raise ValueError('Property NodeManagementResultNode.name is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.status is not None:
                dict_obj["status"] = self.status

            if self.error is not None:
                dict_obj["error"] = self.error

            if self.id is not None:
                dict_obj["id"] = self.id

            if self.name is not None:
                dict_obj["name"] = self.name

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = NodeManagementResultNode()

            value = dict_obj.get('status')
            if value is not None:
                obj.status = value

            value = dict_obj.get('error')
            if value is not None:
                obj.error = value

            value = dict_obj.get('id')
            if value is not None:
                obj.id = value

            value = dict_obj.get('name')
            if value is not None:
                obj.name = value

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return NodeManagementResultNode.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def status(self):
            """
            status: string, One of OK or Error, Optional
            """
            return self._status

        @status.setter
        def status(self, value):
            """
            status: string, One of OK or Error, Optional
            """
            self._status = value

        @property
        def error(self):
            """
            error: string, If the status is Error, this contains the error message, Optional
            """
            return self._error

        @error.setter
        def error(self, value):
            """
            error: string, If the status is Error, this contains the error message, Optional
            """
            self._error = value

        @property
        def id(self):
            """
            id: string, The id of the node, Required
            """
            return self._id

        @id.setter
        def id(self, value):
            """
            id: string, The id of the node, Required
            """
            self._id = value

        @property
        def name(self):
            """
            name: string, The name of the node, Required
            """
            return self._name

        @name.setter
        def name(self, value):
            """
            name: string, The name of the node, Required
            """
            self._name = value


#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from nojythonsupport.model import NodeCreationRequestSet as _NodeCreationRequestSet


    def json_decode(json_string):
        return _NodeCreationRequestSet.json_decode(json_string)


    def from_dict(dict_obj):
        return _NodeCreationRequestSet.from_dict(dict_obj)


    def NodeCreationRequestSet(**kwargs):
        obj = _NodeCreationRequestSet()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    NodeCreationRequestSet.json_decode = _NodeCreationRequestSet.json_decode
    NodeCreationRequestSet.from_dict = _NodeCreationRequestSet.from_dict


else:
    from .NodeCreationRequestSetDefinitionModule import NodeCreationRequestSetDefinition


    def json_decode(json_string):
        return NodeCreationRequestSet.json_decode(json_string)


    def from_dict(dict_obj):
        return NodeCreationRequestSet.from_dict(dict_obj)


    class NodeCreationRequestSet(object):
        """
        
        count: integer, The number of nodes to create, Required
        definition: NodeCreationRequestSetDefinition, The definition of the bucket to use. This is provided by the cluster status API call.  If some of the items given in the status call are missing, or the entire bucket property is missing, the first bucket that matches the given items is used.
, Optional
        nodearray: string, The name of the nodearray to start nodes from, Required
        placement_group_id: string, If given, nodes with the same value for groupId will all be started in the same placement group.
, Optional
        name_offset: integer, If given, along with nameFormat, offsets nodeindex for new nodes.
, Optional
        name_format: string, If given, nodes will use this naming convention instead of the standard "nodearray-%d" format
, Optional
        node_attributes: object, A node record, Optional
        """

        def __init__(self, **kwargs):
            self.count = kwargs.get('count')
            self.definition = kwargs.get('definition')
            self.nodearray = kwargs.get('nodearray')
            self.placement_group_id = kwargs.get('placement_group_id')
            self.name_offset = kwargs.get('name_offset')
            self.name_format = kwargs.get('name_format')
            self.node_attributes = kwargs.get('node_attributes')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.count is None:
                raise ValueError('Property NodeCreationRequestSet.count is required.')
            if self.nodearray is None:
                raise ValueError('Property NodeCreationRequestSet.nodearray is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.count is not None:
                dict_obj["count"] = self.count

            if self.definition is not None:
                dict_obj["definition"] = self.definition.to_dict()

            if self.nodearray is not None:
                dict_obj["nodearray"] = self.nodearray

            if self.placement_group_id is not None:
                dict_obj["placementGroupId"] = self.placement_group_id

            if self.name_offset is not None:
                dict_obj["nameOffset"] = self.name_offset

            if self.name_format is not None:
                dict_obj["nameFormat"] = self.name_format

            if self.node_attributes is not None:
                dict_obj["nodeAttributes"] = self.node_attributes

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = NodeCreationRequestSet()

            value = dict_obj.get('count')
            if value is not None:
                obj.count = value

            value = dict_obj.get('definition')
            if value is not None:
                obj.definition = NodeCreationRequestSetDefinition.from_dict(value)

            value = dict_obj.get('nodearray')
            if value is not None:
                obj.nodearray = value

            value = dict_obj.get('placementgroupid')
            if value is not None:
                obj.placement_group_id = value

            value = dict_obj.get('nameoffset')
            if value is not None:
                obj.name_offset = value

            value = dict_obj.get('nameformat')
            if value is not None:
                obj.name_format = value

            value = dict_obj.get('nodeattributes')
            if value is not None:
                obj.node_attributes = value

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return NodeCreationRequestSet.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def count(self):
            """
            count: integer, The number of nodes to create, Required
            """
            return self._count

        @count.setter
        def count(self, value):
            """
            count: integer, The number of nodes to create, Required
            """
            self._count = value

        @property
        def definition(self):
            """
            definition: NodeCreationRequestSetDefinition, The definition of the bucket to use. This is provided by the cluster status API call.  If some of the items given in the status call are missing, or the entire bucket property is missing, the first bucket that matches the given items is used.
, Optional
            """
            return self._definition

        @definition.setter
        def definition(self, value):
            """
            definition: NodeCreationRequestSetDefinition, The definition of the bucket to use. This is provided by the cluster status API call.  If some of the items given in the status call are missing, or the entire bucket property is missing, the first bucket that matches the given items is used.
, Optional
            """
            if value:
                if isinstance(value, dict):
                    value = NodeCreationRequestSetDefinition.from_dict(value)
                if not isinstance(value, NodeCreationRequestSetDefinition):
                    raise TypeError('Value for NodeCreationRequestSet.definition must be NodeCreationRequestSetDefinition or dict')
            self._definition = value

        @property
        def nodearray(self):
            """
            nodearray: string, The name of the nodearray to start nodes from, Required
            """
            return self._nodearray

        @nodearray.setter
        def nodearray(self, value):
            """
            nodearray: string, The name of the nodearray to start nodes from, Required
            """
            self._nodearray = value

        @property
        def placement_group_id(self):
            """
            placement_group_id: string, If given, nodes with the same value for groupId will all be started in the same placement group.
, Optional
            """
            return self._placement_group_id

        @placement_group_id.setter
        def placement_group_id(self, value):
            """
            placement_group_id: string, If given, nodes with the same value for groupId will all be started in the same placement group.
, Optional
            """
            self._placement_group_id = value

        @property
        def name_offset(self):
            """
            name_offset: integer, If given, along with nameFormat, offsets nodeindex for new nodes.
, Optional
            """
            return self._name_offset

        @name_offset.setter
        def name_offset(self, value):
            """
            name_offset: integer, If given, along with nameFormat, offsets nodeindex for new nodes.
, Optional
            """
            self._name_offset = value

        @property
        def name_format(self):
            """
            name_format: string, If given, nodes will use this naming convention instead of the standard "nodearray-%d" format
, Optional
            """
            return self._name_format

        @name_format.setter
        def name_format(self, value):
            """
            name_format: string, If given, nodes will use this naming convention instead of the standard "nodearray-%d" format
, Optional
            """
            self._name_format = value

        @property
        def node_attributes(self):
            """
            node_attributes: object, A node record, Optional
            """
            return self._node_attributes

        @node_attributes.setter
        def node_attributes(self, value):
            """
            node_attributes: object, A node record, Optional
            """
            self._node_attributes = value


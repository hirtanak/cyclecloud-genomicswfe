#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from nojythonsupport.model import NodeCreationResult as _NodeCreationResult


    def json_decode(json_string):
        return _NodeCreationResult.json_decode(json_string)


    def from_dict(dict_obj):
        return _NodeCreationResult.from_dict(dict_obj)


    def NodeCreationResult(**kwargs):
        obj = _NodeCreationResult()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    NodeCreationResult.json_decode = _NodeCreationResult.json_decode
    NodeCreationResult.from_dict = _NodeCreationResult.from_dict


else:
    from .NodeCreationResultSetModule import NodeCreationResultSet


    def json_decode(json_string):
        return NodeCreationResult.json_decode(json_string)


    def from_dict(dict_obj):
        return NodeCreationResult.from_dict(dict_obj)


    class NodeCreationResult(object):
        """
        
        sets: [NodeCreationResultSet], An array of sets, in the same order as in the request, Required
        operation_id: string, The id of this operation, Required
        """

        def __init__(self, **kwargs):
            self.sets = kwargs.get('sets')
            self.operation_id = kwargs.get('operation_id')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.sets is None:
                raise ValueError('Property NodeCreationResult.sets is required.')
            if self.operation_id is None:
                raise ValueError('Property NodeCreationResult.operation_id is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.sets is not None:
                dict_obj["sets"] = [v.to_dict() for v in self.sets]

            if self.operation_id is not None:
                dict_obj["operationId"] = self.operation_id

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = NodeCreationResult()

            value = dict_obj.get('sets')
            if value is not None:
                obj.sets = []
                for item in value:
                    obj.sets.append(NodeCreationResultSet.from_dict(item))

            value = dict_obj.get('operationid')
            if value is not None:
                obj.operation_id = value

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return NodeCreationResult.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def sets(self):
            """
            sets: [NodeCreationResultSet], An array of sets, in the same order as in the request, Required
            """
            return self._sets

        @sets.setter
        def sets(self, value):
            """
            sets: [NodeCreationResultSet], An array of sets, in the same order as in the request, Required
            """
            if value:
                if type(value) is not list:
                    raise TypeError('Must supply a list for NodeCreationResult.sets.')
            self._sets = value

        @property
        def operation_id(self):
            """
            operation_id: string, The id of this operation, Required
            """
            return self._operation_id

        @operation_id.setter
        def operation_id(self, value):
            """
            operation_id: string, The id of this operation, Required
            """
            self._operation_id = value


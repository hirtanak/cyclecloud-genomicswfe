#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from nojythonsupport.model import NodeCreationResultSet as _NodeCreationResultSet


    def json_decode(json_string):
        return _NodeCreationResultSet.json_decode(json_string)


    def from_dict(dict_obj):
        return _NodeCreationResultSet.from_dict(dict_obj)


    def NodeCreationResultSet(**kwargs):
        obj = _NodeCreationResultSet()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    NodeCreationResultSet.json_decode = _NodeCreationResultSet.json_decode
    NodeCreationResultSet.from_dict = _NodeCreationResultSet.from_dict


else:


    def json_decode(json_string):
        return NodeCreationResultSet.json_decode(json_string)


    def from_dict(dict_obj):
        return NodeCreationResultSet.from_dict(dict_obj)


    class NodeCreationResultSet(object):
        """
        
        message: string, Indicates why not all requested nodes could be added, if present, Optional
        added: integer, How many nodes were started in this set, Required
        """

        def __init__(self, **kwargs):
            self.message = kwargs.get('message')
            self.added = kwargs.get('added')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.added is None:
                raise ValueError('Property NodeCreationResultSet.added is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.message is not None:
                dict_obj["message"] = self.message

            if self.added is not None:
                dict_obj["added"] = self.added

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = NodeCreationResultSet()

            value = dict_obj.get('message')
            if value is not None:
                obj.message = value

            value = dict_obj.get('added')
            if value is not None:
                obj.added = value

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return NodeCreationResultSet.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def message(self):
            """
            message: string, Indicates why not all requested nodes could be added, if present, Optional
            """
            return self._message

        @message.setter
        def message(self, value):
            """
            message: string, Indicates why not all requested nodes could be added, if present, Optional
            """
            self._message = value

        @property
        def added(self):
            """
            added: integer, How many nodes were started in this set, Required
            """
            return self._added

        @added.setter
        def added(self, value):
            """
            added: integer, How many nodes were started in this set, Required
            """
            self._added = value


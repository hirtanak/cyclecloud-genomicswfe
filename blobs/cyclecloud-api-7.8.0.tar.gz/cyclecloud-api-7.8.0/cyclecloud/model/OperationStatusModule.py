#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from nojythonsupport.model import OperationStatus as _OperationStatus


    def json_decode(json_string):
        return _OperationStatus.json_decode(json_string)


    def from_dict(dict_obj):
        return _OperationStatus.from_dict(dict_obj)


    def OperationStatus(**kwargs):
        obj = _OperationStatus()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    OperationStatus.json_decode = _OperationStatus.json_decode
    OperationStatus.from_dict = _OperationStatus.from_dict


else:


    def json_decode(json_string):
        return OperationStatus.json_decode(json_string)


    def from_dict(dict_obj):
        return OperationStatus.from_dict(dict_obj)


    class OperationStatus(object):
        """
        The status of this node operation
        action: ['create'], , Required
        start_time: string, When this operation was submitted, Required
        """
        valid_action = ["create"]

        def __init__(self, **kwargs):
            self.action = kwargs.get('action')
            self.start_time = kwargs.get('start_time')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.action is None:
                raise ValueError('Property OperationStatus.action is required.')
            if self.start_time is None:
                raise ValueError('Property OperationStatus.start_time is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.action is not None:
                dict_obj["action"] = self.action

            if self.start_time is not None:
                dict_obj["startTime"] = self.start_time

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = OperationStatus()

            value = dict_obj.get('action')
            if value is not None:
                obj.action = value

            value = dict_obj.get('starttime')
            if value is not None:
                obj.start_time = value

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return OperationStatus.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def action(self):
            """
            action: ['create'], , Required
            """
            return self._action

        @action.setter
        def action(self, value):
            """
            action: ['create'], , Required
            """
            self._action = value

        @property
        def start_time(self):
            """
            start_time: string, When this operation was submitted, Required
            """
            return self._start_time

        @start_time.setter
        def start_time(self, value):
            """
            start_time: string, When this operation was submitted, Required
            """
            self._start_time = value

